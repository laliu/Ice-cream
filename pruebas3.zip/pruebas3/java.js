    function myfunc() {
    document.getElementById("demo").innerHTML = "The most tasty ice cream ever especially for you!";
}

    function myfunction() {
    document.getElementById("fa").style.display='block';
}
    function funcmy() {
    document.getElementById("sol").style.display='block';
    }
